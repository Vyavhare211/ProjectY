import { GoogleGenAI } from '@google/genai';
import { config } from '../src/config/environment';

async function testGeminiConnection() {
  console.log('--- Testing Gemini API Configuration & Timing ---');
  console.log('GEMINI_API_KEY set:', Boolean(config.geminiApiKey));
  if (config.geminiApiKey) {
    console.log('Key prefix:', config.geminiApiKey.substring(0, 8) + '...');
  }

  if (!config.geminiApiKey) {
    console.log('ℹ️ No GEMINI_API_KEY in environment. Testing fallback structure.');
    return;
  }

  const client = new GoogleGenAI({ apiKey: config.geminiApiKey });

  // Test 1: models.generateContent with timeout
  console.log('\n[Test 1] Testing client.models.generateContent with gemini-2.5-flash / gemini-3.8-flash...');
  const t0 = Date.now();

  const modelsToTry = ['gemini-2.5-flash', 'gemini-3.8-flash', 'gemini-flash-latest', 'gemini-1.5-flash'];
  for (const model of modelsToTry) {
    const tStart = Date.now();
    try {
      console.log(`Trying model "${model}"...`);
      const response = await Promise.race([
        client.models.generateContent({
          model,
          contents: 'Say "Hello, Gemini is working!" in exactly 5 words.',
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout: ${model} took > 10000ms`)), 10000)
        ),
      ]);
      const duration = Date.now() - tStart;
      console.log(`✅ Success with model "${model}" in ${duration}ms!`);
      console.log(`Response text: "${response.text?.trim()}"\n`);
      break;
    } catch (err: any) {
      console.warn(`❌ Model "${model}" failed in ${Date.now() - tStart}ms:`, err.message);
    }
  }

  // Test 2: interactions.create
  console.log('[Test 2] Testing client.interactions.create with 8s timeout...');
  const t2Start = Date.now();
  try {
    const interaction = await Promise.race([
      client.interactions.create({
        model: 'gemini-3.8-flash',
        input: 'Say hello in 3 words.',
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('Timeout: interactions.create took > 8000ms')), 8000)
      ),
    ]);
    console.log(`✅ interactions.create succeeded in ${Date.now() - t2Start}ms: "${interaction.output_text?.trim()}"`);
  } catch (err: any) {
    console.warn(`⚠️ interactions.create failed/timed-out in ${Date.now() - t2Start}ms:`, err.message);
  }
}

testGeminiConnection();
