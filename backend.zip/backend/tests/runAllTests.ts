import { runYouTubeTests } from './youtube.test';
import { runTranscriptTests } from './transcript.test';
import { runRetrievalTests } from './retrieval.test';

console.log('=============================================');
console.log('🧪 Running Backend Test Suite');
console.log('=============================================');

const r1 = runYouTubeTests();
const r2 = runTranscriptTests();
const r3 = runRetrievalTests();

const totalPassed = r1.passed + r2.passed + r3.passed;
const totalFailed = r1.failed + r2.failed + r3.failed;

console.log('\n=============================================');
console.log(`📊 Unit Test Summary: ${totalPassed} Passed, ${totalFailed} Failed`);
console.log('=============================================');

if (totalFailed > 0) {
  process.exit(1);
} else {
  console.log('🎉 All backend unit tests passed successfully!\n');
  process.exit(0);
}
