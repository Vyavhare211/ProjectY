import { extractVideoId, isValidYouTubeUrl } from '../src/services/youtubeService';

export function runYouTubeTests(): { passed: number; failed: number } {
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  console.log('\n--- Running YouTube Service Tests ---');

  // Test 1: Standard watch URL
  const id1 = extractVideoId('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  assert(id1 === 'dQw4w9WgXcQ', 'Extract from standard watch URL');

  // Test 2: Standard watch URL with extra query params
  const id2 = extractVideoId('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=42s&feature=emb_title');
  assert(id2 === 'dQw4w9WgXcQ', 'Extract from watch URL with extra params');

  // Test 3: Short youtu.be URL
  const id3 = extractVideoId('https://youtu.be/dQw4w9WgXcQ?t=10');
  assert(id3 === 'dQw4w9WgXcQ', 'Extract from youtu.be short URL');

  // Test 4: YouTube Shorts URL
  const id4 = extractVideoId('https://www.youtube.com/shorts/dQw4w9WgXcQ');
  assert(id4 === 'dQw4w9WgXcQ', 'Extract from YouTube Shorts URL');

  // Test 5: Embed URL
  const id5 = extractVideoId('https://www.youtube.com/embed/dQw4w9WgXcQ');
  assert(id5 === 'dQw4w9WgXcQ', 'Extract from Embed URL');

  // Test 6: Raw 11-char ID
  const id6 = extractVideoId('dQw4w9WgXcQ');
  assert(id6 === 'dQw4w9WgXcQ', 'Extract from raw 11-char ID');

  // Test 7: Invalid URLs
  assert(extractVideoId('https://vimeo.com/12345678') === null, 'Reject Vimeo URL');
  assert(extractVideoId('https://google.com') === null, 'Reject Google URL');
  assert(extractVideoId('not a url') === null, 'Reject arbitrary non-URL text');
  assert(extractVideoId('') === null, 'Reject empty string');

  // Test 8: isValidYouTubeUrl helper
  assert(isValidYouTubeUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ'), 'isValidYouTubeUrl returns true for valid link');
  assert(!isValidYouTubeUrl('https://facebook.com'), 'isValidYouTubeUrl returns false for Facebook link');

  return { passed, failed };
}
