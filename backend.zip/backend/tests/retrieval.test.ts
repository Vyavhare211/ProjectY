import { tokenize, retrieveRelevantChunks } from '../src/services/retrievalService';
import { TranscriptChunk } from '../src/types';

export function runRetrievalTests(): { passed: number; failed: number } {
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  console.log('\n--- Running Retrieval Service Tests ---');

  // Test 1: tokenize filters stop words
  const tokens = tokenize('What is a Python function in this video?');
  assert(tokens.includes('python') && tokens.includes('function'), 'Tokenize extracts keywords');
  assert(!tokens.includes('what') && !tokens.includes('is') && !tokens.includes('a'), 'Tokenize strips stopwords');

  // Test 2: retrieveRelevantChunks selects matching chunk
  const mockChunks: TranscriptChunk[] = [
    {
      id: 1,
      text: 'In this section we install Python and setup Visual Studio Code on Windows.',
      start: 0,
      end: 45,
      startFormatted: '00:00',
      endFormatted: '00:45',
    },
    {
      id: 2,
      text: 'Now let us understand normalization in database management systems like 1NF, 2NF, and 3NF.',
      start: 50,
      end: 110,
      startFormatted: '00:50',
      endFormatted: '01:50',
    },
    {
      id: 3,
      text: 'Recursion is a method of solving problems where the solution depends on solutions to smaller instances.',
      start: 115,
      end: 175,
      startFormatted: '01:55',
      endFormatted: '02:55',
    },
  ];

  const results1 = retrieveRelevantChunks(mockChunks, 'What is normalization in database?', 1);
  assert(results1.length === 1, 'Returns 1 relevant chunk');
  assert(results1[0].id === 2, 'Selected chunk 2 for normalization query');

  const results2 = retrieveRelevantChunks(mockChunks, 'recursion base case', 1);
  assert(results2.length === 1, 'Returns 1 relevant chunk for recursion');
  assert(results2[0].id === 3, 'Selected chunk 3 for recursion query');

  return { passed, failed };
}
