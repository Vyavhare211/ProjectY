import { formatTimestamp, chunkTranscript } from '../src/services/transcriptService';
import { TranscriptSegment } from '../src/types';

export function runTranscriptTests(): { passed: number; failed: number } {
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  console.log('\n--- Running Transcript Service Tests ---');

  // Test 1: formatTimestamp under 1 minute
  assert(formatTimestamp(45) === '00:45', 'Format seconds < 60');

  // Test 2: formatTimestamp in minutes
  assert(formatTimestamp(125) === '02:05', 'Format seconds in MM:SS');

  // Test 3: formatTimestamp over 1 hour
  assert(formatTimestamp(3665) === '01:01:05', 'Format seconds in HH:MM:SS');

  // Test 4: chunkTranscript with empty list
  assert(chunkTranscript([]).length === 0, 'Chunk empty segments returns empty array');

  // Test 5: chunkTranscript groups segments correctly
  const sampleSegments: TranscriptSegment[] = [
    { start: 0, duration: 5, text: 'Hello and welcome to this comprehensive Python tutorial.' },
    { start: 5, duration: 6, text: 'Today we will be discussing functions and variables.' },
    { start: 12, duration: 4, text: 'A function is defined using the def keyword.' },
    { start: 70, duration: 5, text: 'Next, let us look at how return statements work in Python.' },
    { start: 76, duration: 6, text: 'When a return statement executes, the function exits immediately.' },
  ];

  const chunks = chunkTranscript(sampleSegments, 20); // small word limit to force multiple chunks
  assert(chunks.length >= 2, 'Segments split into multiple chronological chunks');
  assert(chunks[0].startFormatted === '00:00', 'First chunk starts at 00:00');
  assert(chunks[0].text.includes('Python tutorial'), 'First chunk contains initial text');
  assert(chunks[chunks.length - 1].text.includes('return statement'), 'Last chunk contains trailing text');

  return { passed, failed };
}
