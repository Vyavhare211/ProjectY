import { answerQuestionFromVideo } from '../src/services/geminiService';
import { TranscriptChunk } from '../src/types';

async function testGroundedChat() {
  console.log('======================================================');
  console.log('🧪 Testing Grounded Gemini Q&A Pipeline with Live Timings');
  console.log('======================================================\n');

  const mockChunks: TranscriptChunk[] = [
    {
      id: 1,
      text: 'Welcome to Python. Today we will learn about functions. In Python, a function is a named block of reusable code defined with the def keyword.',
      start: 0,
      end: 35,
      startFormatted: '00:00',
      endFormatted: '00:35',
    },
    {
      id: 2,
      text: 'Functions can take input parameters inside parentheses and return values using the return statement. For example, def add_numbers(a, b): return a + b.',
      start: 36,
      end: 80,
      startFormatted: '00:36',
      endFormatted: '01:20',
    },
    {
      id: 3,
      text: 'Next, we discuss variables, integers, strings, and boolean values like True and False.',
      start: 81,
      end: 120,
      startFormatted: '01:21',
      endFormatted: '02:00',
    },
  ];

  // Test 1: Grounded question
  console.log('[Test 1] Asking Grounded Question: "How is a function defined in Python and what keyword is used?"');
  const t1 = Date.now();
  try {
    const res1 = await answerQuestionFromVideo('Python Tutorial for Beginners', mockChunks, 'How is a function defined in Python and what keyword is used?');
    const d1 = Date.now() - t1;
    console.log(`\n✅ [Grounded Test] Completed in ${d1}ms:`);
    console.log(`- Answer: "${res1.answer}"`);
    console.log(`- Grounded: ${res1.grounded}`);
    console.log(`- Confidence: ${res1.confidence}`);
    console.log(`- Citations:`, res1.sourceSegments);
  } catch (err: any) {
    console.error(`❌ [Grounded Test Failed] in ${Date.now() - t1}ms:`, err.message);
  }

  // Test 2: Unsupported question
  console.log('\n------------------------------------------------------');
  console.log('[Test 2] Asking Unsupported Question: "What is the capital of Australia and how far is Sydney?"');
  const t2 = Date.now();
  try {
    const res2 = await answerQuestionFromVideo('Python Tutorial for Beginners', mockChunks, 'What is the capital of Australia and how far is Sydney?');
    const d2 = Date.now() - t2;
    console.log(`\n✅ [Unsupported Test] Completed in ${d2}ms:`);
    console.log(`- Answer: "${res2.answer}"`);
    console.log(`- Grounded: ${res2.grounded}`);
    console.log(`- Confidence: ${res2.confidence}`);
  } catch (err: any) {
    console.error(`❌ [Unsupported Test Failed] in ${Date.now() - t2}ms:`, err.message);
  }
}

testGroundedChat();
