import { GoogleGenAI } from '@google/genai';
import { config } from '../src/config/environment';

async function probeAvailableModels() {
  if (!config.geminiApiKey) {
    console.log('No API key found');
    return;
  }

  const client = new GoogleGenAI({ apiKey: config.geminiApiKey });

  console.log('--- Probing Supported Gemini Models via client.models.list() ---');
  try {
    const list = await client.models.list();
    console.log('Listing available models:');
    for await (const m of list) {
      console.log(`- ${m.name} (${m.displayName || ''})`);
    }
  } catch (err: any) {
    console.warn('Could not list models directly:', err.message);
  }

  // Probe specific candidate models
  const candidates = [
    'gemini-3.8-flash',
    'gemini-3.5-flash-lite',
    'gemini-3.1-pro-preview',
    'gemini-3.1-flash-lite',
    'gemini-flash-latest',
  ];

  console.log('\n--- Testing Candidate Models for Speed & Responsiveness ---');
  for (const model of candidates) {
    const t0 = Date.now();
    try {
      console.log(`Calling model "${model}"...`);
      const res = await Promise.race([
        client.models.generateContent({
          model,
          contents: 'Reply with the single word "READY".',
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('TIMEOUT_6S')), 6000)
        ),
      ]);
      const duration = Date.now() - t0;
      console.log(`✅ [${model}] SUCCESS in ${duration}ms! Text: "${res.text?.trim()}"`);
    } catch (err: any) {
      const duration = Date.now() - t0;
      console.log(`❌ [${model}] FAILED in ${duration}ms: ${err.message}`);
    }
  }
}

probeAvailableModels();
