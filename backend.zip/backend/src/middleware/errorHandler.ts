import { Request, Response, NextFunction } from 'express';

export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
): void {
  console.error('[API Error]:', err.stack || err.message || err);

  const statusCode = err.status || err.statusCode || 500;
  const userMessage = err.message || 'An unexpected server error occurred. Please try again.';

  res.status(statusCode).json({
    error: err.name || 'ServerError',
    message: userMessage,
  });
}
