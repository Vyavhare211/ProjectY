import { Request, Response, NextFunction } from 'express';
import { verifyAuthToken } from '../services/firebaseAdminService';
import { AuthenticatedUser } from '../types';

export interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUser;
}

export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Missing Authorization header. Please sign in.',
    });
    return;
  }

  const token = authHeader.startsWith('Bearer ')
    ? authHeader.substring(7).trim()
    : authHeader.trim();

  if (!token) {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Invalid Authorization header format.',
    });
    return;
  }

  try {
    const user = await verifyAuthToken(token);
    req.user = user;
    next();
  } catch (err) {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Authentication session expired or invalid. Please sign in again.',
    });
  }
}
