import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware';
import { getSessionFromMemory, getMessagesFromMemory, storeMessageInMemory } from '../services/firebaseAdminService';
import { retrieveRelevantChunks } from '../services/retrievalService';
import { answerQuestionFromVideo } from '../services/geminiService';
import { ChatMessage, ChatResponse } from '../types';

export async function askQuestion(req: AuthenticatedRequest, res: Response): Promise<void> {
  const reqStartTime = Date.now();
  const { sessionId, question } = req.body;
  const user = req.user;

  console.log(`\n======================================================`);
  console.log(`[ROUTE: /api/chat] New Question Received at ${new Date().toISOString()}`);
  console.log(`User UID: ${user?.uid || 'anonymous'}`);
  console.log(`Session ID: ${sessionId}`);
  console.log(`Question: "${question}"`);
  console.log(`======================================================`);

  if (!user || !user.uid) {
    res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    return;
  }

  if (!sessionId || typeof sessionId !== 'string') {
    res.status(400).json({ error: 'BadRequest', message: 'sessionId is required' });
    return;
  }

  if (!question || typeof question !== 'string' || !question.trim()) {
    res.status(400).json({ error: 'BadRequest', message: 'Please provide a valid question.' });
    return;
  }

  // 1. Session lookup
  const tSessionStart = Date.now();
  const session = getSessionFromMemory(sessionId);
  console.log(`[TIMING] Step 1 (Session Lookup) took ${Date.now() - tSessionStart}ms`);

  if (!session) {
    res.status(404).json({
      error: 'NotFound',
      message: 'Video session not found. Please analyze the video again.',
    });
    return;
  }

  // Security check: User A cannot query User B's session
  if (session.userId !== user.uid) {
    console.warn(`[SECURITY] Access denied: User ${user.uid} attempted to access session ${sessionId} owned by ${session.userId}`);
    res.status(403).json({
      error: 'Forbidden',
      message: 'You do not have permission to access this video session.',
    });
    return;
  }

  // Check if transcript is available
  if (!session.transcriptChunks || session.transcriptChunks.length === 0) {
    console.log(`[TIMING] Session has 0 transcript chunks. Returning no_transcript response immediately.`);
    res.status(200).json({
      answer: "We couldn't obtain usable transcript information for this video, so video-specific Q&A is unavailable.",
      grounded: false,
      confidence: 'unsupported',
      sourceSegments: [],
      sessionId,
    });
    return;
  }

  try {
    // 2. Retrieve top relevant chunks based on user's question
    const tRetrievalStart = Date.now();
    const relevantChunks = retrieveRelevantChunks(session.transcriptChunks, question.trim(), 6);
    console.log(`[TIMING] Step 2 (Context Retrieval) took ${Date.now() - tRetrievalStart}ms. Retrieved ${relevantChunks.length} chunks.`);

    // 3. Load recent conversation messages
    const tHistoryStart = Date.now();
    const previousMessages = getMessagesFromMemory(sessionId);
    const chatHistory = previousMessages.map((m) => ({
      role: m.role,
      content: m.content,
    }));
    console.log(`[TIMING] Step 3 (Chat History Lookup) took ${Date.now() - tHistoryStart}ms (${chatHistory.length} previous messages).`);

    // 4. Generate grounded answer with Gemini with failover and timeout
    console.log(`[TIMING] Step 4: Dispatching Gemini Grounded Q&A...`);
    const tAiStart = Date.now();
    const aiResult = await answerQuestionFromVideo(
      session.title,
      relevantChunks,
      question.trim(),
      chatHistory
    );
    console.log(`[TIMING] Step 4 (Gemini Pipeline Total) completed in ${Date.now() - tAiStart}ms`);

    const now = new Date().toISOString();

    // 5. Save User & Assistant messages to history
    const tPersistStart = Date.now();
    const userMessage: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      sessionId,
      userId: user.uid,
      role: 'user',
      content: question.trim(),
      createdAt: now,
    };
    storeMessageInMemory(userMessage);

    const assistantMessage: ChatMessage = {
      id: `msg_asst_${Date.now() + 1}`,
      sessionId,
      userId: user.uid,
      role: 'assistant',
      content: aiResult.answer,
      grounded: aiResult.grounded,
      confidence: aiResult.confidence,
      sourceSegments: aiResult.sourceSegments,
      createdAt: new Date().toISOString(),
    };
    storeMessageInMemory(assistantMessage);
    console.log(`[TIMING] Step 5 (History Persistence) took ${Date.now() - tPersistStart}ms`);

    const responsePayload: ChatResponse = {
      answer: aiResult.answer,
      grounded: aiResult.grounded,
      confidence: aiResult.confidence,
      sourceSegments: aiResult.sourceSegments,
      sessionId,
    };

    const totalRouteDuration = Date.now() - reqStartTime;
    console.log(`[TIMING] ✅ Total /api/chat Request Completed in ${totalRouteDuration}ms [Grounded: ${aiResult.grounded}, Confidence: ${aiResult.confidence}]\n`);

    res.status(200).json(responsePayload);
  } catch (err: any) {
    const totalFailedDuration = Date.now() - reqStartTime;
    console.error(`[TIMING] ❌ /api/chat Failed after ${totalFailedDuration}ms:`, err.message);
    res.status(500).json({
      error: 'AIProcessingError',
      message: err.message || 'The AI service encountered an error while analyzing the video. Please try again.',
    });
  }
}
