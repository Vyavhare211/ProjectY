import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware';
import {
  getUserSessionsFromMemory,
  getSessionFromMemory,
  getMessagesFromMemory,
  deleteSessionFromMemory,
} from '../services/firebaseAdminService';

export async function getUserSessions(req: AuthenticatedRequest, res: Response): Promise<void> {
  const user = req.user;
  if (!user || !user.uid) {
    res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    return;
  }

  const sessions = getUserSessionsFromMemory(user.uid);
  // Omit heavy full transcript text from list preview
  const sanitized = sessions.map((s) => ({
    id: s.id,
    userId: s.userId,
    videoId: s.videoId,
    videoUrl: s.videoUrl,
    title: s.title,
    channelTitle: s.channelTitle,
    thumbnail: s.thumbnail,
    duration: s.duration,
    transcriptChunkCount: s.transcriptChunkCount,
    createdAt: s.createdAt,
    updatedAt: s.updatedAt,
  }));

  res.status(200).json({ sessions: sanitized });
}

export async function getSessionById(req: AuthenticatedRequest, res: Response): Promise<void> {
  const { id } = req.params;
  const user = req.user;

  if (!user || !user.uid) {
    res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    return;
  }

  const session = getSessionFromMemory(id);
  if (!session) {
    res.status(404).json({ error: 'NotFound', message: 'Session not found' });
    return;
  }

  if (session.userId !== user.uid) {
    res.status(403).json({ error: 'Forbidden', message: 'Access denied to this session' });
    return;
  }

  res.status(200).json({ session });
}

export async function getSessionMessages(req: AuthenticatedRequest, res: Response): Promise<void> {
  const { id } = req.params;
  const user = req.user;

  if (!user || !user.uid) {
    res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    return;
  }

  const session = getSessionFromMemory(id);
  if (!session) {
    res.status(404).json({ error: 'NotFound', message: 'Session not found' });
    return;
  }

  if (session.userId !== user.uid) {
    res.status(403).json({ error: 'Forbidden', message: 'Access denied to this session' });
    return;
  }

  const messages = getMessagesFromMemory(id);
  res.status(200).json({ messages });
}

export async function deleteSession(req: AuthenticatedRequest, res: Response): Promise<void> {
  const { id } = req.params;
  const user = req.user;

  if (!user || !user.uid) {
    res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    return;
  }

  const session = getSessionFromMemory(id);
  if (!session) {
    res.status(404).json({ error: 'NotFound', message: 'Session not found' });
    return;
  }

  if (session.userId !== user.uid) {
    res.status(403).json({ error: 'Forbidden', message: 'Access denied' });
    return;
  }

  deleteSessionFromMemory(id);
  res.status(200).json({ success: true, message: 'Session deleted successfully' });
}
