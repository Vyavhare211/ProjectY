import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware';
import { extractVideoId, fetchVideoMetadata } from '../services/youtubeService';
import { fetchTranscript, chunkTranscript } from '../services/transcriptService';
import { storeSessionInMemory, getSessionFromMemory } from '../services/firebaseAdminService';
import { VideoSession, AnalyzeVideoResponse } from '../types';

export async function analyzeVideo(req: AuthenticatedRequest, res: Response): Promise<void> {
  const { youtubeUrl } = req.body;
  const user = req.user;

  if (!user || !user.uid) {
    res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    return;
  }

  if (!youtubeUrl || typeof youtubeUrl !== 'string') {
    res.status(400).json({
      error: 'BadRequest',
      message: 'Please enter a valid YouTube video link.',
    });
    return;
  }

  const videoId = extractVideoId(youtubeUrl);
  if (!videoId) {
    res.status(400).json({
      error: 'InvalidUrl',
      message: 'Please enter a valid YouTube video link (e.g., https://www.youtube.com/watch?v=...).',
    });
    return;
  }

  try {
    // 1. Fetch video metadata
    const metadata = await fetchVideoMetadata(videoId);

    // 2. Fetch and chunk transcript
    let chunks: any[] = [];
    let status: 'ready' | 'no_transcript' = 'ready';
    let errorMessage: string | undefined;

    try {
      const segments = await fetchTranscript(videoId);
      chunks = chunkTranscript(segments);
    } catch (transcriptErr: any) {
      console.warn(`[Analyze] Transcript unavailable for ${videoId}:`, transcriptErr.message);
      status = 'no_transcript';
      errorMessage = transcriptErr.message || "We couldn't obtain usable transcript information for this video.";
    }

    // 3. Generate unique session ID
    const sessionId = `${user.uid}_${videoId}_${Date.now()}`;
    const now = new Date().toISOString();

    const session: VideoSession = {
      id: sessionId,
      userId: user.uid,
      videoId,
      videoUrl: metadata.videoUrl,
      title: metadata.title,
      channelTitle: metadata.channelTitle,
      thumbnail: metadata.thumbnail,
      duration: metadata.duration,
      transcriptChunkCount: chunks.length,
      transcriptChunks: chunks,
      createdAt: now,
      updatedAt: now,
    };

    // Store in session store
    storeSessionInMemory(session);

    const responsePayload: AnalyzeVideoResponse = {
      sessionId: session.id,
      videoId: session.videoId,
      videoUrl: session.videoUrl,
      title: session.title,
      channelTitle: session.channelTitle || 'YouTube Creator',
      thumbnail: session.thumbnail || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      transcriptChunkCount: session.transcriptChunkCount,
      status,
      message: errorMessage,
    };

    res.status(200).json(responsePayload);
  } catch (err: any) {
    console.error('[Analyze Video Error]:', err);
    res.status(500).json({
      error: 'ProcessingError',
      message: 'Failed to process YouTube video. Please check the URL and try again.',
    });
  }
}
