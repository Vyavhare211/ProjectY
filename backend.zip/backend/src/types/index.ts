export interface TranscriptSegment {
  text: string;
  start: number; // in seconds
  duration: number; // in seconds
}

export interface TranscriptChunk {
  id: number;
  text: string;
  start: number; // in seconds
  end: number; // in seconds
  startFormatted: string; // "MM:SS" or "HH:MM:SS"
  endFormatted: string; // "MM:SS" or "HH:MM:SS"
}

export interface VideoMetadata {
  videoId: string;
  videoUrl: string;
  title: string;
  channelTitle?: string;
  thumbnail?: string;
  duration?: string;
}

export interface SourceSegment {
  start: number;
  timestamp: string;
  quote: string;
}

export interface VideoSession {
  id: string;
  userId: string;
  videoId: string;
  videoUrl: string;
  title: string;
  channelTitle?: string;
  thumbnail?: string;
  duration?: string;
  transcriptChunkCount: number;
  transcriptChunks?: TranscriptChunk[];
  summary?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  sessionId: string;
  userId: string;
  role: 'user' | 'assistant';
  content: string;
  grounded?: boolean;
  confidence?: 'supported' | 'partial' | 'unsupported';
  sourceSegments?: SourceSegment[];
  createdAt: string;
}

export interface ChatRequest {
  sessionId: string;
  question: string;
}

export interface ChatResponse {
  answer: string;
  grounded: boolean;
  confidence: 'supported' | 'partial' | 'unsupported';
  sourceSegments: SourceSegment[];
  sessionId: string;
}

export interface AnalyzeVideoRequest {
  youtubeUrl: string;
}

export interface AnalyzeVideoResponse {
  sessionId: string;
  videoId: string;
  videoUrl: string;
  title: string;
  channelTitle: string;
  thumbnail: string;
  transcriptChunkCount: number;
  status: 'ready' | 'no_transcript';
  message?: string;
}

export interface AuthenticatedUser {
  uid: string;
  email?: string;
  displayName?: string;
}
