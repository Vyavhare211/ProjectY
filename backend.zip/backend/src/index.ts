import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { config } from './config/environment';
import { initializeFirebaseAdmin } from './services/firebaseAdminService';
import { simpleRateLimiter } from './middleware/rateLimiter';
import { errorHandler } from './middleware/errorHandler';

import videoRoutes from './routes/videoRoutes';
import chatRoutes from './routes/chatRoutes';
import sessionRoutes from './routes/sessionRoutes';

const app = express();

// Initialize Firebase Admin SDK
initializeFirebaseAdmin();

// Middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

app.use(
  cors({
    origin: ['http://localhost:5173', 'http://localhost:3000', 'http://127.0.0.1:5173', config.frontendUrl],
    credentials: true,
  })
);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(simpleRateLimiter(120, 60 * 1000));

// Health Check
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    geminiConfigured: Boolean(config.geminiApiKey),
    nodeEnv: config.nodeEnv,
  });
});

// API Routes
app.use('/api/video', videoRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/sessions', sessionRoutes);

// Global Error Handler
app.use(errorHandler);

// Start Server
const server = app.listen(config.port, () => {
  console.log(`
=====================================================
🚀 YouTube AI Summarizer Backend API Server Running
📡 URL: http://localhost:${config.port}
🤖 Gemini AI API: ${config.geminiApiKey ? '✅ Configured' : '⚠️ Missing GEMINI_API_KEY'}
🔒 Security: Grounded Anti-Hallucination Pipeline Active
=====================================================
  `);
});

export default app;
