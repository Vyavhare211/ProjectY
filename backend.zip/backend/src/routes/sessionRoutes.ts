import { Router } from 'express';
import {
  getUserSessions,
  getSessionById,
  getSessionMessages,
  deleteSession,
} from '../controllers/sessionController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

// GET /api/sessions
router.get('/', requireAuth, getUserSessions);

// GET /api/sessions/:id
router.get('/:id', requireAuth, getSessionById);

// GET /api/sessions/:id/messages
router.get('/:id/messages', requireAuth, getSessionMessages);

// DELETE /api/sessions/:id
router.delete('/:id', requireAuth, deleteSession);

export default router;
