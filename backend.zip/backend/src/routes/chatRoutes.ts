import { Router } from 'express';
import { askQuestion } from '../controllers/chatController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

// POST /api/chat
router.post('/', requireAuth, askQuestion);

export default router;
