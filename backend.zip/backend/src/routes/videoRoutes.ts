import { Router } from 'express';
import { analyzeVideo } from '../controllers/videoController';
import { requireAuth } from '../middleware/authMiddleware';

const router = Router();

// POST /api/video/analyze
router.post('/analyze', requireAuth, analyzeVideo);

export default router;
