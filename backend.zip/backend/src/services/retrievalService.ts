import { TranscriptChunk } from '../types';

const STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'aren\'t', 'as', 'at',
  'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by',
  'can', 'can\'t', 'cannot', 'could', 'couldn\'t', 'did', 'didn\'t', 'do', 'does', 'doesn\'t', 'doing', 'don\'t', 'down', 'during',
  'each', 'few', 'for', 'from', 'further', 'had', 'hadn\'t', 'has', 'hasn\'t', 'have', 'haven\'t', 'having', 'he', 'he\'d', 'he\'ll', 'he\'s', 'her', 'here', 'here\'s', 'hers', 'herself', 'him', 'himself', 'his', 'how', 'how\'s',
  'i', 'i\'d', 'i\'ll', 'i\'m', 'i\'ve', 'if', 'in', 'into', 'is', 'isn\'t', 'it', 'it\'s', 'its', 'itself',
  'let\'s', 'me', 'more', 'most', 'mustn\'t', 'my', 'myself',
  'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours', 'ourselves', 'out', 'over', 'own',
  'same', 'shan\'t', 'she', 'she\'d', 'she\'ll', 'she\'s', 'should', 'shouldn\'t', 'so', 'some', 'such',
  'than', 'that', 'that\'s', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', 'there\'s', 'these', 'they', 'they\'d', 'they\'ll', 'they\'re', 'they\'ve', 'this', 'those', 'through', 'to', 'too',
  'under', 'until', 'up', 'very',
  'was', 'wasn\'t', 'we', 'we\'d', 'we\'ll', 'we\'re', 'we\'ve', 'were', 'weren\'t', 'what', 'what\'s', 'when', 'when\'s', 'where', 'where\'s', 'which', 'while', 'who', 'who\'s', 'whom', 'why', 'why\'s', 'with', 'won\'t', 'would', 'wouldn\'t',
  'you', 'you\'d', 'you\'ll', 'you\'re', 'you\'ve', 'your', 'yours', 'yourself', 'yourselves',
  'tell', 'explain', 'video', 'show', 'says', 'mentioned', 'discuss', 'give'
]);

/**
 * Tokenizes text into lowercase alphanumeric keywords excluding stop words.
 */
export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1 && !STOP_WORDS.has(w));
}

/**
 * Scores a transcript chunk against query tokens using term frequency and bigram proximity.
 */
function scoreChunk(chunk: TranscriptChunk, queryTokens: string[], rawQueryLower: string): number {
  const chunkTextLower = chunk.text.toLowerCase();
  const chunkTokens = tokenize(chunk.text);
  if (chunkTokens.length === 0) return 0;

  const chunkTokenFreq = new Map<string, number>();
  for (const t of chunkTokens) {
    chunkTokenFreq.set(t, (chunkTokenFreq.get(t) || 0) + 1);
  }

  let score = 0;

  // Exact phrase boost
  if (rawQueryLower.length > 5 && chunkTextLower.includes(rawQueryLower)) {
    score += 25.0;
  }

  // Token frequency scoring
  for (const qt of queryTokens) {
    const tf = chunkTokenFreq.get(qt) || 0;
    if (tf > 0) {
      // Logarithmic TF
      score += (1 + Math.log(tf)) * 3.0;
    }
  }

  // Bigram matches
  for (let i = 0; i < queryTokens.length - 1; i++) {
    const bigram = `${queryTokens[i]} ${queryTokens[i + 1]}`;
    if (chunkTextLower.includes(bigram)) {
      score += 6.0;
    }
  }

  return score;
}

/**
 * Retrieves the most relevant transcript chunks for a question.
 * Returns chunks sorted in chronological order so context maintains narrative flow.
 */
export function retrieveRelevantChunks(
  allChunks: TranscriptChunk[],
  question: string,
  maxChunks: number = 6
): TranscriptChunk[] {
  if (!allChunks || allChunks.length === 0) return [];

  // If the total chunks are small enough, send all of them
  if (allChunks.length <= maxChunks) {
    return allChunks;
  }

  const rawQueryLower = question.toLowerCase().trim();
  const queryTokens = tokenize(question);

  // If query consists only of common stop words, take first few chunks + evenly spaced
  if (queryTokens.length === 0) {
    return allChunks.slice(0, maxChunks);
  }

  const scored = allChunks.map((chunk) => ({
    chunk,
    score: scoreChunk(chunk, queryTokens, rawQueryLower),
  }));

  // Sort descending by relevance score
  scored.sort((a, b) => b.score - a.score);

  // Take top scored chunks with score > 0
  const topScored = scored.filter((s) => s.score > 0).slice(0, maxChunks);

  // If no chunks scored > 0, fallback to first few chunks (e.g. video intro/overview)
  if (topScored.length === 0) {
    return allChunks.slice(0, maxChunks);
  }

  // Sort selected chunks by original chunk ID (chronological order)
  const selectedChunks = topScored.map((s) => s.chunk);
  selectedChunks.sort((a, b) => a.id - b.id);

  return selectedChunks;
}
