import { GoogleGenAI } from '@google/genai';
import { config } from '../config/environment';
import { TranscriptChunk, ChatResponse, SourceSegment } from '../types';

let genAIClient: GoogleGenAI | null = null;

function getClient(): GoogleGenAI {
  if (!genAIClient) {
    if (!config.geminiApiKey) {
      throw new Error('GEMINI_API_KEY is not configured in backend environment variables.');
    }
    genAIClient = new GoogleGenAI({ apiKey: config.geminiApiKey });
  }
  return genAIClient;
}

const SYSTEM_INSTRUCTION = `You are a video-specific question answering assistant.
You may answer ONLY using information contained in the provided video transcript/content.
Do not use general world knowledge to fill gaps.
Do not invent information.
Do not infer unsupported facts.
If the user's question cannot be answered from the provided video content, respond:
'I couldn't find that information in this video.'
If only part of the answer is supported, answer only the supported portion and clearly indicate that the remaining information was not covered.
Always stay within the scope of the current video.

You MUST respond strictly with a valid JSON object formatted as follows:
{
  "answer": "A clear, grounded response referencing the video explanations or 'I couldn't find that information in this video.'",
  "grounded": true or false (false if the video does not contain information to answer the question),
  "confidence": "supported" | "partial" | "unsupported",
  "sourceSegments": [
    {
      "start": 124,
      "timestamp": "02:04",
      "quote": "Direct brief quote from the transcript supporting this point"
    }
  ]
}
Do NOT include markdown code fences (\`\`\`json) around your output if possible. Return only raw JSON.`;

// Prioritized model fallback waterfall
// gemini-3.5-flash-lite and gemini-3.1-flash-lite provide sub-second responses when 3.8 encounters high demand spikes (503).
const CANDIDATE_MODELS = [
  'gemini-3.5-flash-lite',
  'gemini-3.8-flash',
  'gemini-3.1-flash-lite',
  'gemini-3.7-flash',
  'gemini-flash-latest',
];

/**
 * Executes a generation request with a strict timeout.
 */
async function callModelWithTimeout(
  client: GoogleGenAI,
  model: string,
  fullPrompt: string,
  timeoutMs: number = 10000
): Promise<{ text: string; modelUsed: string; durationMs: number }> {
  const t0 = Date.now();

  const apiPromise = client.models.generateContent({
    model,
    contents: fullPrompt,
  });

  const timeoutPromise = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error(`Timeout: Model ${model} did not respond within ${timeoutMs}ms`)), timeoutMs);
  });

  const response = await Promise.race([apiPromise, timeoutPromise]);
  const durationMs = Date.now() - t0;

  const rawText = response.text || '';
  if (!rawText.trim()) {
    throw new Error(`Model ${model} returned an empty response text.`);
  }

  return { text: rawText, modelUsed: model, durationMs };
}

/**
 * Calls Gemini with strictly retrieved video transcript chunks to generate a grounded answer.
 * Includes multi-tier model failover and granular timing telemetry.
 */
export async function answerQuestionFromVideo(
  videoTitle: string,
  chunks: TranscriptChunk[],
  question: string,
  chatHistory: { role: string; content: string }[] = []
): Promise<ChatResponse> {
  const overallStart = Date.now();
  const client = getClient();

  // 1. Format the transcript context with exact timestamps
  const tFormatStart = Date.now();
  const formattedContext = chunks
    .map(
      (c) =>
        `[Timestamp ${c.startFormatted} - ${c.endFormatted} (start: ${Math.floor(c.start)}s)]:\n${c.text}`
    )
    .join('\n\n');

  // Format recent chat history if available
  const historyText =
    chatHistory.length > 0
      ? chatHistory
          .slice(-4)
          .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
          .join('\n')
      : 'No previous conversation.';

  const prompt = `${SYSTEM_INSTRUCTION}

VIDEO TITLE: "${videoTitle}"

AVAILABLE VIDEO TRANSCRIPT CONTEXT:
---
${formattedContext}
---

RECENT CHAT CONVERSATION:
${historyText}

USER QUESTION: "${question}"

Remember: Answer ONLY using information explicitly present in the provided transcript context above. If the question asks about something not mentioned in the transcript, set "grounded": false, "confidence": "unsupported", and "answer": "I couldn't find that information in this video."`;

  const formatDuration = Date.now() - tFormatStart;
  console.log(`[TIMING] Context preparation took ${formatDuration}ms (${chunks.length} chunks, ~${prompt.length} chars)`);

  let rawOutput = '';
  let successfulModel = '';
  let lastError: Error | null = null;

  // 2. Multi-model failover execution
  const tAiStart = Date.now();
  for (const model of CANDIDATE_MODELS) {
    try {
      console.log(`[TIMING] Invoking Gemini model: "${model}" (timeout: 10s)...`);
      const result = await callModelWithTimeout(client, model, prompt, 10000);
      rawOutput = result.text;
      successfulModel = result.modelUsed;
      console.log(`[TIMING] ✅ Gemini model "${successfulModel}" responded in ${result.durationMs}ms`);
      break;
    } catch (err: any) {
      lastError = err;
      const failDuration = Date.now() - tAiStart;
      console.warn(`[TIMING] ⚠️ Model "${model}" failed/timed out in ${failDuration}ms: ${err.message}. Trying next candidate...`);
    }
  }

  if (!rawOutput) {
    const totalFailedDuration = Date.now() - overallStart;
    console.error(`[TIMING] ❌ All Gemini candidate models failed after ${totalFailedDuration}ms. Last error:`, lastError);
    throw new Error(
      lastError?.message?.includes('Timeout')
        ? 'The AI model took too long to respond. Please try asking again in a few moments.'
        : `AI generation failed: ${lastError?.message || 'Upstream service unavailable'}`
    );
  }

  // 3. Parse JSON & Validate Grounding
  const tParseStart = Date.now();
  const cleanJson = rawOutput.replace(/```json/gi, '').replace(/```/g, '').trim();

  try {
    const parsed = JSON.parse(cleanJson);
    const isGrounded = Boolean(parsed.grounded);
    const confidence = (['supported', 'partial', 'unsupported'].includes(parsed.confidence)
      ? parsed.confidence
      : isGrounded
      ? 'supported'
      : 'unsupported') as 'supported' | 'partial' | 'unsupported';

    const sourceSegments: SourceSegment[] = Array.isArray(parsed.sourceSegments)
      ? parsed.sourceSegments.map((s: any) => ({
          start: Number(s.start) || 0,
          timestamp: String(s.timestamp || '00:00'),
          quote: String(s.quote || ''),
        }))
      : [];

    const parseDuration = Date.now() - tParseStart;
    const totalDuration = Date.now() - overallStart;
    console.log(`[TIMING] Response parsing & grounding validation took ${parseDuration}ms. [Total Pipeline Time: ${totalDuration}ms]`);

    // Grounding validation guardrail
    if (!isGrounded || confidence === 'unsupported') {
      return {
        answer: parsed.answer || "I couldn't find that information in this video.",
        grounded: false,
        confidence: 'unsupported',
        sourceSegments: [],
        sessionId: '',
      };
    }

    return {
      answer: parsed.answer,
      grounded: true,
      confidence,
      sourceSegments,
      sessionId: '',
    };
  } catch (jsonErr) {
    console.warn('[Gemini] Response was not strict JSON, evaluating unstructured response:', rawOutput);
    const lower = rawOutput.toLowerCase();
    const isUnsupported =
      lower.includes("couldn't find") ||
      lower.includes('not found in this video') ||
      lower.includes('not mentioned in the video');

    const totalDuration = Date.now() - overallStart;
    console.log(`[TIMING] Unstructured fallback completed in ${totalDuration}ms`);

    return {
      answer: isUnsupported ? "I couldn't find that information in this video." : rawOutput,
      grounded: !isUnsupported,
      confidence: isUnsupported ? 'unsupported' : 'supported',
      sourceSegments: [],
      sessionId: '',
    };
  }
}
