import { VideoMetadata } from '../types';

/**
 * Extracts a standard YouTube video ID (11 characters) from various URL formats.
 */
export function extractVideoId(input: string): string | null {
  if (!input || typeof input !== 'string') return null;
  const trimmed = input.trim();

  // If input is already an 11-char alphanumeric ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  // Regex patterns covering standard watch, short URL, shorts, embed, and query parameters
  const patterns = [
    /(?:https?:\/\/)?(?:www\.|m\.)?youtube\.com\/watch\?(?:.*&)?v=([a-zA-Z0-9_-]{11})(?:&.*)?/i,
    /(?:https?:\/\/)?youtu\.be\/([a-zA-Z0-9_-]{11})(?:\?.*)?/i,
    /(?:https?:\/\/)?(?:www\.|m\.)?youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})(?:\?.*)?/i,
    /(?:https?:\/\/)?(?:www\.|m\.)?youtube\.com\/embed\/([a-zA-Z0-9_-]{11})(?:\?.*)?/i,
    /(?:https?:\/\/)?(?:www\.|m\.)?youtube\.com\/v\/([a-zA-Z0-9_-]{11})(?:\?.*)?/i,
  ];

  for (const pattern of patterns) {
    const match = trimmed.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }

  return null;
}

/**
 * Validates whether the provided string is a valid YouTube URL or video ID.
 */
export function isValidYouTubeUrl(input: string): boolean {
  return extractVideoId(input) !== null;
}

/**
 * Fetches real video metadata from YouTube's official oEmbed service.
 */
export async function fetchVideoMetadata(videoId: string): Promise<VideoMetadata> {
  const canonicalUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const defaultThumbnail = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

  try {
    const oEmbedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(canonicalUrl)}&format=json`;
    const response = await fetch(oEmbedUrl);

    if (response.ok) {
      const data = (await response.json()) as any;
      return {
        videoId,
        videoUrl: canonicalUrl,
        title: data.title || `YouTube Video (${videoId})`,
        channelTitle: data.author_name || 'YouTube Creator',
        thumbnail: data.thumbnail_url || defaultThumbnail,
      };
    }
  } catch (err) {
    console.warn(`Could not fetch oEmbed metadata for ${videoId}:`, err);
  }

  // Fallback metadata if oEmbed fails
  return {
    videoId,
    videoUrl: canonicalUrl,
    title: `YouTube Video (${videoId})`,
    channelTitle: 'YouTube Creator',
    thumbnail: defaultThumbnail,
  };
}
