import { YoutubeTranscript } from 'youtube-transcript';
import { TranscriptSegment, TranscriptChunk } from '../types';

/**
 * Formats seconds into "MM:SS" or "HH:MM:SS".
 */
export function formatTimestamp(seconds: number): string {
  const totalSeconds = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;

  const paddedMinutes = String(minutes).padStart(2, '0');
  const paddedSecs = String(secs).padStart(2, '0');

  if (hours > 0) {
    const paddedHours = String(hours).padStart(2, '0');
    return `${paddedHours}:${paddedMinutes}:${paddedSecs}`;
  }
  return `${paddedMinutes}:${paddedSecs}`;
}

/**
 * Decodes HTML entities commonly found in YouTube subtitles.
 */
function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#x2F;/g, '/')
    .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(dec))
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Native scraper fallback: attempts to extract timedtext caption tracks directly from YouTube watch page.
 */
async function fetchTranscriptDirectFallback(videoId: string, timeoutMs: number = 8000): Promise<TranscriptSegment[]> {
  const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;
  
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(watchUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to load YouTube watch page (status ${response.status})`);
    }

    const html = await response.text();

    // Locate ytInitialPlayerResponse
    const match = html.match(/ytInitialPlayerResponse\s*=\s*({.+?});(?:var|\s*<\/script>)/);
    if (!match || !match[1]) {
      throw new Error('Could not locate player data in video page');
    }

    let playerResponse: any;
    try {
      playerResponse = JSON.parse(match[1]);
    } catch {
      throw new Error('Failed to parse player response JSON');
    }

    const captionTracks = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    if (!captionTracks || !captionTracks.length) {
      throw new Error('No caption tracks found for this video');
    }

    // Find English or fallback to first track
    const track = captionTracks.find((t: any) => t.languageCode === 'en') || captionTracks[0];
    const baseUrl = track.baseUrl;
    if (!baseUrl) {
      throw new Error('Caption track base URL is missing');
    }

    const captionsResponse = await fetch(baseUrl, { signal: controller.signal });
    if (!captionsResponse.ok) {
      throw new Error('Failed to fetch caption XML from base URL');
    }

    const xmlText = await captionsResponse.text();
    const segments: TranscriptSegment[] = [];

    // Parse <text start="12.34" dur="4.56">Some text</text>
    const regex = /<text\s+start="([\d.]+)"(?:\s+dur="([\d.]+)")?[^>]*>(.*?)<\/text>/g;
    let m: RegExpExecArray | null;

    while ((m = regex.exec(xmlText)) !== null) {
      const start = parseFloat(m[1]);
      const duration = m[2] ? parseFloat(m[2]) : 3.0;
      const text = decodeHtmlEntities(m[3]);
      if (text) {
        segments.push({ start, duration, text });
      }
    }

    if (segments.length === 0) {
      throw new Error('No text elements found in caption track');
    }

    return segments;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Fetches transcript segments for a given video ID using multi-strategy fallback with timeouts.
 */
export async function fetchTranscript(videoId: string): Promise<TranscriptSegment[]> {
  const t0 = Date.now();
  console.log(`[TIMING] Starting transcript extraction for video ID: ${videoId}`);

  // Strategy 1: youtube-transcript library with 8s timeout
  try {
    const tLibStart = Date.now();
    const rawItems = await Promise.race([
      YoutubeTranscript.fetchTranscript(videoId),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('youtube-transcript library timed out (>8s)')), 8000)
      ),
    ]);

    if (rawItems && rawItems.length > 0) {
      const duration = Date.now() - tLibStart;
      console.log(`[TIMING] ✅ Strategy 1 (youtube-transcript) succeeded in ${duration}ms (${rawItems.length} segments)`);
      return rawItems.map((item) => ({
        start: item.offset / 1000,
        duration: item.duration / 1000,
        text: decodeHtmlEntities(item.text),
      }));
    }
  } catch (err: any) {
    console.warn(`[TIMING] ⚠️ Strategy 1 failed in ${Date.now() - t0}ms: ${err.message}. Trying Strategy 2...`);
  }

  // Strategy 2: Direct timedtext extraction fallback with 8s timeout
  try {
    const tDirectStart = Date.now();
    const fallbackSegments = await fetchTranscriptDirectFallback(videoId, 8000);
    if (fallbackSegments && fallbackSegments.length > 0) {
      const duration = Date.now() - tDirectStart;
      console.log(`[TIMING] ✅ Strategy 2 (direct timedtext) succeeded in ${duration}ms (${fallbackSegments.length} segments)`);
      return fallbackSegments;
    }
  } catch (err: any) {
    console.warn(`[TIMING] ⚠️ Strategy 2 failed in ${Date.now() - t0}ms: ${err.message}`);
  }

  const totalFailTime = Date.now() - t0;
  console.warn(`[TIMING] ❌ Transcript retrieval failed for ${videoId} after ${totalFailTime}ms.`);
  throw new Error("We couldn't obtain usable transcript information for this video, so video-specific Q&A is unavailable.");
}

/**
 * Groups raw transcript segments into clean, searchable chunks with start/end timestamps.
 */
export function chunkTranscript(segments: TranscriptSegment[], maxChunkWords: number = 180): TranscriptChunk[] {
  const tChunkStart = Date.now();
  if (!segments || segments.length === 0) return [];

  const chunks: TranscriptChunk[] = [];
  let currentChunkTexts: string[] = [];
  let chunkStart = segments[0].start;
  let chunkEnd = segments[0].start + segments[0].duration;
  let currentWordCount = 0;
  let chunkId = 1;

  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    const words = seg.text.split(/\s+/).filter(Boolean);
    const segEnd = seg.start + seg.duration;

    if (currentChunkTexts.length === 0) {
      chunkStart = seg.start;
    }

    currentChunkTexts.push(seg.text);
    currentWordCount += words.length;
    chunkEnd = Math.max(chunkEnd, segEnd);

    // If reached max words or gap is large, close the chunk
    const isLastSegment = i === segments.length - 1;
    const timeSpan = chunkEnd - chunkStart;

    if (currentWordCount >= maxChunkWords || timeSpan >= 60 || isLastSegment) {
      const combinedText = currentChunkTexts.join(' ').replace(/\s+/g, ' ').trim();

      if (combinedText.length > 0) {
        chunks.push({
          id: chunkId++,
          text: combinedText,
          start: chunkStart,
          end: chunkEnd,
          startFormatted: formatTimestamp(chunkStart),
          endFormatted: formatTimestamp(chunkEnd),
        });
      }

      currentChunkTexts = [];
      currentWordCount = 0;
    }
  }

  console.log(`[TIMING] Transcript chunking took ${Date.now() - tChunkStart}ms (generated ${chunks.length} chunks)`);
  return chunks;
}
