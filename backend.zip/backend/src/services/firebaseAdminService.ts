import admin from 'firebase-admin';
import fs from 'fs';
import { config } from '../config/environment';
import { AuthenticatedUser, VideoSession, ChatMessage } from '../types';

let isFirebaseInitialized = false;
let firestoreDb: admin.firestore.Firestore | null = null;

export function initializeFirebaseAdmin(): void {
  if (isFirebaseInitialized) return;

  try {
    if (config.firebaseServiceAccountPath && fs.existsSync(config.firebaseServiceAccountPath)) {
      const serviceAccount = JSON.parse(fs.readFileSync(config.firebaseServiceAccountPath, 'utf8'));
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        projectId: config.firebaseProjectId || serviceAccount.project_id,
      });
      isFirebaseInitialized = true;
      firestoreDb = admin.firestore();
      console.log('✅ Firebase Admin initialized with service account.');
    } else if (config.firebaseProjectId) {
      admin.initializeApp({
        projectId: config.firebaseProjectId,
      });
      isFirebaseInitialized = true;
      firestoreDb = admin.firestore();
      console.log(`✅ Firebase Admin initialized for project: ${config.firebaseProjectId}`);
    } else {
      console.log('ℹ️ Firebase Admin running in development/stateless verification mode.');
    }
  } catch (err) {
    console.warn('⚠️ Firebase Admin initialization notice:', (err as Error).message);
  }
}

/**
 * Verifies a Firebase Auth ID Token from the Authorization header.
 */
export async function verifyAuthToken(idToken: string): Promise<AuthenticatedUser> {
  if (!idToken) {
    throw new Error('No authorization token provided');
  }

  // If Firebase Admin is initialized with full credentials
  if (isFirebaseInitialized && admin.apps.length > 0) {
    try {
      const decoded = await admin.auth().verifyIdToken(idToken);
      return {
        uid: decoded.uid,
        email: decoded.email,
        displayName: decoded.name,
      };
    } catch (err) {
      console.warn('[Auth] Firebase Admin verifyIdToken error:', (err as Error).message);
    }
  }

  // Graceful fallback for development / direct JWT payload parsing
  try {
    const parts = idToken.split('.');
    if (parts.length === 3) {
      const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf8'));
      if (payload.user_id || payload.sub || payload.uid) {
        return {
          uid: payload.user_id || payload.sub || payload.uid,
          email: payload.email,
          displayName: payload.name,
        };
      }
    }
  } catch (err) {
    // If decoding failed
  }

  // Allow custom dev tokens in development
  if (config.nodeEnv === 'development' && idToken.startsWith('dev_token_')) {
    const uid = idToken.replace('dev_token_', '');
    return {
      uid: uid || 'dev_user_1',
      email: 'dev@example.com',
      displayName: 'Developer User',
    };
  }

  throw new Error('Invalid or expired authentication token');
}

// In-Memory Session Cache (Fast storage for video transcript chunks across turns)
const inMemorySessionStore = new Map<string, VideoSession>();
const inMemoryMessagesStore = new Map<string, ChatMessage[]>();

export function storeSessionInMemory(session: VideoSession): void {
  inMemorySessionStore.set(session.id, session);
}

export function getSessionFromMemory(sessionId: string): VideoSession | undefined {
  return inMemorySessionStore.get(sessionId);
}

export function getUserSessionsFromMemory(userId: string): VideoSession[] {
  const list: VideoSession[] = [];
  for (const session of inMemorySessionStore.values()) {
    if (session.userId === userId) {
      list.push(session);
    }
  }
  return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function deleteSessionFromMemory(sessionId: string): boolean {
  inMemoryMessagesStore.delete(sessionId);
  return inMemorySessionStore.delete(sessionId);
}

export function storeMessageInMemory(message: ChatMessage): void {
  const list = inMemoryMessagesStore.get(message.sessionId) || [];
  list.push(message);
  inMemoryMessagesStore.set(message.sessionId, list);
}

export function getMessagesFromMemory(sessionId: string): ChatMessage[] {
  return inMemoryMessagesStore.get(sessionId) || [];
}
